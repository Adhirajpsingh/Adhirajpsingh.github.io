import sys, subprocess
from tabulate import tabulate
import mysql.connector as mc
import time
from datetime import date

# ------------------ Database Setup ------------------
mydb = mc.connect(host='localhost', user='root', password='root')
mycur = mydb.cursor()

# Create database and use it
mycur.execute('CREATE DATABASE IF NOT EXISTS cafe_management;')
mycur.execute('USE cafe_management')

# Credentials Table
mycur.execute('''
    CREATE TABLE IF NOT EXISTS credentials (
        post VARCHAR(20) PRIMARY KEY,
        password VARCHAR(20)
    )
''')

# Insert predefined credentials if not already there
mycur.execute("SELECT * FROM credentials WHERE post='ADMIN'")
if not mycur.fetchall():
    mycur.execute('''
        INSERT INTO credentials (post, password)
        VALUES 
        ('ADMIN','99'),
        ('kitchen','88'),
        ('reception','77')
    ''')
    mydb.commit()

# Menu Table
mycur.execute('''
    CREATE TABLE IF NOT EXISTS menu (
        Dish VARCHAR(20),
        D_code VARCHAR(20) PRIMARY KEY,
        cost DECIMAL(10,2) NOT NULL
    )
''')

# Permanent Log Table (recreate to enforce AUTO_INCREMENT)
mycur.execute('''
    CREATE TABLE IF NOT EXISTS permanent_log (
        orderno INT AUTO_INCREMENT PRIMARY KEY,
        D_code VARCHAR(20),
        order_date DATE,
        FOREIGN KEY (D_code) REFERENCES menu(D_code)
        )
    ''')

# Current Orders Table (recreate to enforce AUTO_INCREMENT)
mycur.execute("DROP TABLE IF EXISTS current_orders")
mycur.execute('''
    CREATE TABLE current_orders (
        orderno INT AUTO_INCREMENT PRIMARY KEY,
        D_code VARCHAR(20),
        order_date DATE,
        Dish VARCHAR(20),
        Quantity int,
        FOREIGN KEY (D_code) REFERENCES menu(D_code)
    )
''')

mydb.commit()

# ------------------ Login ------------------
def login(pst):
    print(f"\n--- LOGIN ({pst.upper()}) ---")
    print('''[PREDEFINED PASSWORD  CAN BE CHANGED!]
              ('ADMIN','99'),
              ('kitchen','88'),
              ('reception','77')''')
    attempts = 3
    while attempts > 0:
        password = input('Enter your password: ')
        mycur.execute("SELECT password FROM credentials WHERE post=%s", (pst,))
        result = mycur.fetchone()
        for i in range(0,6):
            if i%2==0:                
                print('Checking Password Library ....',)
                time.sleep(1)
                subprocess.run('cls',shell=True)
            else:
                print('Checking Password Library ...',)
                time.sleep(1)
                subprocess.run('cls',shell=True)
        if result and password == result[0]:
            return True
        else:
            print('Incorrect password, try again.')
            attempts -= 1
    print(" Too many failed attempts. Exiting...")
    sys.exit()

# ------------------- Menu Module -------------------
def show_menu():
    print("\n---  Cafe Menu ---")
    mycur.execute("SELECT Dish, D_code, cost FROM menu")
    rows = mycur.fetchall()

    if not rows:
        print(" Menu is empty.")
    else:
        print(tabulate(rows, headers=["Dish", "Code", "Price (₹)"], tablefmt="pretty"))

# ------------------ Password Change ------------------
def psw_chng():
    print(''' 
        |ADMIN    |
        |kitchen  |
        |reception|''')
    ip1 = input('Enter the post you want to change the password of: ')
    ip2 = input('Enter the current password: ')

    mycur.execute("SELECT password FROM credentials WHERE post=%s", (ip1,))
    result = mycur.fetchone()

    if result is None:
        print("Post not found.")
        return

    current_password = result[0]

    if ip2 != current_password:
        print("Wrong password. Exiting...")
        sys.exit()
    
    print('Starting password change sequence...')
    time.sleep(3)
    for i in range(0,2):
            if i%2==0:                
                print('processing ....')
                time.sleep(1)
                subprocess.run('cls',shell=True)
            else:
                print('processing ...')
                time.sleep(1)
                subprocess.run('cls',shell=True)
    new_password = input('Enter the new password: ')

    if new_password == current_password:
        print("New password must be different from the old one.")
        return

    mycur.execute("UPDATE credentials SET password=%s WHERE post=%s", (new_password, ip1))
    mydb.commit()
    print(" Password updated successfully.")

# ------------------ Menu ------------------
def menu():
    print('''
          ------ Create Menu ------ 1
          ----------Edit Menu--------- 2
          (note: menu can only be created once)''')

    choice = int(input('What would you like to do? :- '))

    if choice == 1:
        entries = int(input('Enter the number of dishes: '))
        for i in range(entries):
            dish = input('Enter the dish name: ')
            dcode = input("Enter the dish code: ")
            cost = float(input('Enter cost: '))
            mycur.execute("INSERT INTO menu (Dish, D_code, cost) VALUES (%s, %s, %s)", (dish, dcode, cost))
            mydb.commit()
            more = input("Add more? (y/n): ")
            if more.lower() == 'n':
                break

    elif choice == 2:
        for i in range(0,6):
            if i%2==0:                
                print('processing ....')
                time.sleep(1)
                subprocess.run('cls',shell=True)
            else:
                print('processing ...')
                time.sleep(1)
                subprocess.run('cls',shell=True)
        
        mycur.execute("SELECT * FROM menu")
        rows = mycur.fetchall()
        print(tabulate(rows, headers=mycur.column_names, tablefmt='pretty'))

        print('''What would you like to do ?
                  1. Add a dish
                  2. Delete a dish
                  3. Edit dish (name/cost)''')
        c = int(input('Enter your choice: '))

        if c == 1:
            dish = input('Enter dish name: ')
            dcode = input('Enter dish code: ')
            cost = float(input('Enter cost: '))
            mycur.execute("INSERT INTO menu (Dish, D_code, cost) VALUES (%s, %s, %s)", (dish, dcode, cost))
            mydb.commit()

        elif c == 2:
            code = input('Enter the dish code to delete: ')
            mycur.execute("DELETE FROM menu WHERE D_code = %s", (code,))
            mydb.commit()

        elif c == 3:
            code = input("Enter dish code to edit: ")
            field = input("Edit name or cost? (n/c): ")
            if field == 'n':
                new_name = input("Enter new dish name: ")
                mycur.execute("UPDATE menu SET Dish=%s WHERE D_code=%s", (new_name, code))
            else:
                new_cost = float(input("Enter new cost: "))
                mycur.execute("UPDATE menu SET cost=%s WHERE D_code=%s", (new_cost, code))
            mydb.commit()

# ------------------ Reception ------------------
def reception():
    while True:
        print('''\n--- RECEPTION MENU ---
        1. Place new order
        2. View current orders
        3. Exit reception''')

        choice = int(input('Enter choice: '))
        
        billdict={}
        total_bill=0.0

        if choice == 1:
            order_No=input('enter the order number: ')
            while True:
                show_menu()                
                code = input("Enter dish code: ")
                qun=int(input('Quantity: '))
                mycur.execute("SELECT Dish FROM menu WHERE D_code=%s", (code,))
                dish = mycur.fetchone()
                if not dish:
                   print("Invalid dish code.")
                   continue
                today = date.today()
                mycur.execute("select cost from menu where D_code=%s",(code,))
                itemcost=mycur.fetchone()
                bill=itemcost[0]*qun
                billint=int(bill)
                total_bill+=billint
                billdict[dish]=qun
               
                
                cont=input('Want to continue: (Y/N)')
                if cont in 'Nn':
                    show_menu()
                    print('order number:',order_No)
                    for key, value in billdict.items():
                      print(f"{key}: {value}")
                    print('total bill',total_bill)
                    input('press enter when bill is paid')
                    break

                

            # Add to current_orders
                
                mycur.execute("INSERT INTO current_orders (D_code, order_date, Dish, Quantity) VALUES (%s, %s, %s,%s)",
                          (code, today, dish[0],qun))
            # Add to permanent_log
                mycur.execute("INSERT INTO permanent_log (D_code, order_date) VALUES (%s, %s)", (code, today))
                mydb.commit()
                print("Order placed.")

        elif choice == 2:
            show_menu()
            mycur.execute("SELECT * FROM current_orders")
            rows = mycur.fetchall()
            print(tabulate(rows, headers=mycur.column_names, tablefmt='pretty'))

        elif choice == 3:
            print("Exiting reception...")
            opening_window()
            

# ------------------ Kitchen ------------------
def kitchen():
    while True:
        print('''\n--- KITCHEN MENU ---
        1. View current orders
        2. Complete an order
        3. Exit kitchen''')

        choice = int(input('Enter choice: '))

        if choice == 1:
            show_menu()
            mycur.execute("SELECT * FROM current_orders")
            rows = mycur.fetchall()
            print(tabulate(rows, headers=mycur.column_names, tablefmt='pretty'))

        elif choice == 2:
            show_menu()
            orderno = int(input("Enter order number to complete: "))
            mycur.execute("DELETE FROM current_orders WHERE orderno=%s", (orderno,))
            mydb.commit()
            print(" Order completed and removed from current orders.")

        elif choice == 3:
            print("Exiting kitchen...")
            opening_window()

# ------------------ Admin ------------------
def admin():
    while True:
        print('''\n--- ADMIN MENU ---
        1. Change Password
        2. Menu Management
        3. permanent log      
        4. Exit Admin''')

        choice = int(input('Enter choice: '))

        if choice == 1:
            psw_chng()
        elif choice == 2:
            menu()
        elif choice==3:
            mycur.execute("SELECT * FROM permanent_log")
            rows = mycur.fetchall()

            if not rows:
                print(" log is empty.")
            else:
                print(tabulate(rows, headers=["orderno", "D_code", "order_date"], tablefmt="pretty"))

            

        elif choice == 4:
            print("Exiting admin...")
            opening_window()

# ------------------ Main ------------------
def opening_window():

    print('''\nWelcome to Cafe Management
    Login as:
   1. Admin
   2. Reception
   3. Kitchen
   4. EXIT SOFTWARE
''')

    role_choice = int(input("Enter choice: "))
    if role_choice == 1:
        if login("ADMIN"):
            admin()
    elif role_choice == 2:
        if login("reception"):
            reception()
    elif role_choice == 3:
        if login("kitchen"):
            kitchen()
    elif role_choice==4:
        sys.exit()
opening_window()
